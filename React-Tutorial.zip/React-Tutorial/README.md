Este proyecto se inició con Create React App .
y siguiendo el tutorial de Nick Germaine y la documentación 
que se desarrolla en el curso

citando las especificaciones del desarrollo del proyecto 
según Nick Germaine 

Guiones disponibles
En el directorio del proyecto, puede ejecutar:

npm start
Ejecuta la aplicación en el modo de desarrollo.
Debe Abrir http://localhost:3000 para verlo en el navegador.

La página se volverá a cargar si realiza modificaciones.
También verá cualquier error de pelusa en la consola.

npm test
Inicia el corredor de prueba en el modo de reloj interactivo.
Consulte la sección sobre la ejecución de pruebas para obtener más información.

npm run build
Crea la aplicación para la producción en la buildcarpeta.
Empaqueta correctamente React en modo de producción y optimiza la compilación para obtener el mejor rendimiento.

La compilación se minimiza y los nombres de archivo incluyen los hashes.
¡la aplicación está lista para ser implementada!

Puede consultar la sección sobre implementación para obtener más información.

npm run eject
Nota: esta es una operación unidireccional. ¡Una vez que lo haces eject, no puedes volver atrás!

Si no está satisfecho con la herramienta de compilación y las opciones de configuración, puede hacerlo ejecten cualquier momento. Este comando eliminará la dependencia de compilación única de su proyecto.

En cambio, copiará todos los archivos de configuración y las dependencias transitivas (Webpack, Babel, ESLint, etc.) directamente en su proyecto para que tenga control total sobre ellos. Todos los comandos excepto ejectseguirán funcionando, pero apuntarán a los scripts copiados para que pueda modificarlos. En este punto estás por tu cuenta.

No tienes que usar nunca eject. El conjunto de funciones seleccionadas es adecuado para implementaciones pequeñas y medianas, y no debe sentirse obligado a usar esta función. Sin embargo, entendemos que esta herramienta no sería útil si no pudiera personalizarla cuando esté listo para ello.


